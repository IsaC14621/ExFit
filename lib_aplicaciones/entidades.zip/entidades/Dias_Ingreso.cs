﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Dias_Ingreso
    {
        public int Id { get; set; }
        public string? Huella { get; set; }
        public int Tipo_Membresia { get; set; }
        public int id_Cliente { get; set; }
        public DateTime Hora_ingreso { get; set; }
        public DateTime Hora_salida { get; set; }

    }
}
