﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Reservas_Clases
    {
        public int Id { get; set; }
        public int id_Clase { get; set; }
        public int Tipo_Cliente { get; set; }
        public int Tipo_Membresia { get; set; }
        public DateTime Fecha_Reserva { get; set; }
        public bool Asistencia { get; set; }

    }
}
