﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    internal class Tienda_E_inventario
    {
        public int Id { get; set; }
        public int id_Producto { get; set; }
        public decimal Precio { get; set; }
        public int Cantidad_Disponible { get; set; }
        public int Cantidad_Productos { get; set; }
        public int Id_Provedor { get; set; }


    }
}
