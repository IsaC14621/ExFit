﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Trabajadores
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public int Identificacion { get; set; }
        public string? Cargo { get; set; }
        public Decimal Salario { get; set; }
        public int Edad { get; set; }

    }
}
