﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    internal class Productos
    {
        public int Id { get; set; }
        public int id_Cliente { get; set; }
        public int Id_Vendedor { get; set; }
        public string  Nombre_Producto { get; set; }
        public DateTime Fecha_Venta { get; set; }
        public decimal Total { get; set; }
    }
}
