﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Clases
    {
        public int Id { get; set; }
        public string? Nombre_Clase { get; set; }
        public int Tipo_Clase { get; set; }
        public DateTime Fecha { get; set; }
        public string? Horario { get; set; }

    }
}
