﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Membresias
    {
        public int Id { get; set; }
        public int Cliente { get; set; }
        public bool TusaFit { get; set; }
        public bool SuperaFit { get; set; }
        public bool SanandoFit { get; set; }
        public bool NomasExs { get; set; }

    }
}
