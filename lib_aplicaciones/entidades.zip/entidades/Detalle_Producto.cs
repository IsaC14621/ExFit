﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    internal class Detalle_Producto
    {
        public int Id { get; set; }
        public int id_Venta { get; set; }
        public int Id_Producto { get; set; }
        public int Cantidad { get; set; }
        public decimal Subtotal { get; set; }
    }
}
