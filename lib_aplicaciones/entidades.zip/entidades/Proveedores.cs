﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    internal class Proveedores
    {
        public int Id { get; set; }
        public int id_Tienda{ get; set; }
        public string Nombre_Empresa { get; set; }
        public string Tipo_Producto { get; set; }
        public string? Direccioon { get; set; }
    }
}
