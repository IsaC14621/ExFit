﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Gym
    {
        public int Id { get; set; }
        public string? Direccion { get; set; }
        public string? Telefono { get; set; }
        public DateTime Fecha { get; set; }
        public string? Horario { get; set; }

    } 
}
