﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Rutinas_Personalizadas 
    {
        public int Id { get; set; }
        public int id_Cliente { get; set; }
        public string? Nombre_Rutina{ get; set; }
        public DateTime Fecha_Inicio { get; set; }
        public string? Objetivo { get; set; }

    }
}
