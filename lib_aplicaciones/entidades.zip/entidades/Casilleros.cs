﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Casilleros
    {
        public int Id { get; set; }
        public int id_Casillero { get; set; }
        public int Numero_Casillero { get; set; }
        public int id_Cliente { get; set; }
        public string? Estado { get; set; }   

    }
}
