﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lib_aplicaciones.entidades
{
    public class Clientes
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Identificacion{ get; set; }
        public int Membresia { get; set; }
        public int Edad { get; set; }
        public string? Huella { get; set; }

    }
}
